import React from 'react';
import ReactCountryFlag from "react-country-flag";
import { Select, Tooltip } from 'antd';

const Lang = () => {
    const langItems = [
        {
            value: 'EN',
            label: <div className='flex gap-[8px] items-center'><ReactCountryFlag countryCode='US' /><span>US. English</span></div>
        },
        {
            value: 'VI',
            label: <div className='flex gap-[8px] items-center'><ReactCountryFlag countryCode='VN' /><span>VN. Vietnamese</span></div>
        },

    ]
    return (
        <div className='changeLanguage float-right'>
            <Tooltip title='Change language for this client!'>
                <Select
                    defaultValue={'EN'}
                    options={langItems}
                />
            </Tooltip>
        </div>
    )
}

export default Lang;